#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "Miller_Rabin.h"  // 소수 판별 알고리즘
#include "RSA_KeyGen.h"    // RSA 키 생성 라이브러리

/**
 * 공개키 파일에서 n, e 값을 읽는 함수
 * 
 * RSA 암호화에 필요한 공개키(n, e)를 지정된 파일에서 읽어옵니다.
 * 이 함수는 주로 기존 키를 사용하는 경우에 사용됩니다.
 * 현재 구현에서는 직접 키를 생성하므로 사용되지 않습니다.
 * 
 * 매개변수:
 * filename: 공개키가 저장된 파일 경로
 * n: 모듈러스 n을 저장할 포인터
 * e: 지수 e를 저장할 포인터
 * 
 * 반환값: 
 * 성공 시 1, 실패 시 0
 */
int read_public_key(const char* filename, uint64_t* n, uint64_t* e) {
    FILE* key_file = fopen(filename, "r");
    if (key_file == NULL) {
        printf("공개키 파일을 열 수 없습니다: %s\n", filename);
        return 0;
    }
    
    if (fscanf(key_file, "%lu %lu", n, e) != 2) {
        printf("공개키 파일에서 n과 e를 읽는데 실패했습니다.\n");
        fclose(key_file);
        return 0;
    }
    
    fclose(key_file);
    return 1;
}

/**
 * 평문을 RSA 알고리즘으로 암호화하는 함수
 * 
 * 입력 파일에서 데이터를 읽어 RSA 알고리즘으로 암호화한 후,
 * 암호화된 데이터를 출력 파일에 기록합니다.
 * 
 * 암호화 과정:
 * 1. 평문을 고정 크기 블록으로 읽음
 * 2. 각 블록을 정수 값으로 변환
 * 3. RSA 공식(C = M^e mod n)을 적용하여 암호화
 * 4. 암호화된 정수 값을 출력 파일에 기록
 * 
 * 매개변수:
 * infile: 평문 데이터가 저장된 입력 파일 포인터
 * outfile: 암호화된 데이터를 기록할 출력 파일 포인터
 * n: RSA 모듈러스
 * e: RSA 공개키 지수
 */
void process_encryption(FILE* infile, FILE* outfile, uint64_t n, uint64_t e) {
    // n의 크기에 따라 한 번에 처리할 바이트 수 결정
    // n이 64비트이므로 최대 8바이트까지 한 번에 처리 가능
    // 하지만 오버플로우 방지를 위해 6바이트만 처리 (48비트)
    const int BLOCK_SIZE = 6;
    uint8_t buffer[BLOCK_SIZE];
    size_t bytes_read;
    
    // 파일에서 블록 단위로 데이터 읽기
    while ((bytes_read = fread(buffer, 1, BLOCK_SIZE, infile)) > 0) {
        // 바이트 배열을 하나의 정수 값(M)으로 변환 (빅 엔디안 방식)
        uint64_t M = 0;
        for (size_t i = 0; i < bytes_read; i++) {
            M = (M << 8) | buffer[i];
        }
        
        // RSA 암호화 공식: C = M^e mod n
        uint64_t C = mod_pow(M, e, n);
        
        // 암호화된 값(C)을 파일에 쓰기 (한 줄에 하나의 암호문 블록)
        fprintf(outfile, "%lu\n", C);
    }
}

/**
 * 메인 함수: RSA 암호화 과정을 조정하고 실행
 * 
 * 명령줄 인수로 입력 파일과 출력 파일 경로를 받아, 다음 단계를 수행합니다:
 * 1. RSA 키 쌍(공개키, 개인키) 생성
 * 2. 입력 파일에서 평문 데이터 읽기
 * 3. RSA 알고리즘으로 데이터 암호화
 * 4. 암호화된 데이터와 공개키를 출력 파일에 저장
 * 
 * 이 구현에서는 생성된 공개키(n, e)를 암호문 파일의 첫 줄에 저장하여,
 * 복호화 시 별도의 키 파일 없이도 복호화가 가능하도록 합니다.
 * (실제 응용에서는 키와 암호문을 분리하는 것이 바람직합니다)
 * 
 * 매개변수:
 * argc: 명령줄 인수 개수
 * argv: 명령줄 인수 배열 (argv[1]은 입력 파일, argv[2]는 출력 파일)
 * 
 * 반환값:
 * 성공 시 0, 실패 시 1
 */
int main(int argc, char *argv[]) {
    // 명령줄 인수 검사
    if (argc != 3) {
        printf("사용법: %s <입력파일> <출력파일>\n", argv[0]);
        return 1;
    }
    
    const char* input_file = argv[1];
    const char* output_file = argv[2];
    
    uint64_t n, e, d;
    
    // RSA 키 쌍 생성 (RSA_KeyGen.h에 정의된 함수 사용)
    if (!generate_rsa_keys(&n, &e, &d)) {
        printf("RSA 키 생성에 실패했습니다.\n");
        return 1;
    }
    
    // 평문 입력 파일 열기 (바이너리 모드)
    FILE* infile = fopen(input_file, "rb");
    if (infile == NULL) {
        printf("입력 파일을 열 수 없습니다: %s\n", input_file);
        return 1;
    }
    
    // 암호문 출력 파일 열기 (텍스트 모드)
    FILE* outfile = fopen(output_file, "w");
    if (outfile == NULL) {
        printf("출력 파일을 열 수 없습니다: %s\n", output_file);
        fclose(infile);
        return 1;
    }
    
    // 암호문 파일의 첫 줄에 공개키(n, e) 저장
    // 복호화 프로그램에서 이 값들을 읽어 사용함
    fprintf(outfile, "%lu %lu\n", n, e);
    
    // 암호화 수행
    process_encryption(infile, outfile, n, e);
    
    // 파일 닫기
    fclose(infile);
    fclose(outfile);
    
    // 완료 메시지 출력
    printf("암호화가 완료되었습니다.\n");
    printf("공개키 (n=%lu, e=%lu)가 암호문 파일 첫 줄에 저장되었습니다.\n", n, e);
    return 0;
}
