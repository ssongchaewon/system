#include <stdio.h>
#include <stdint.h>  // 64비트 정수형을 위한 헤더
#include <stdlib.h>  // 난수 생성 함수(srand, rand) 사용
#include <time.h>    // 난수 시드 설정을 위한 time 함수
#include "Miller_Rabin.h" // 소수 판별 알고리즘 사용

/**
 * 의사 난수 함수 f(x) = (x^2 + c) mod n
 * 
 * Pollard-Rho 알고리즘에서 난수 수열을 생성하는 핵심 함수입니다.
 * 이 함수는 수열의 다음 값을 계산하여 반환합니다.
 * 
 * 매개변수:
 * x: 현재 값
 * c: 상수항 (무작위로 선택됨)
 * n: 모듈러 연산의 법(modulus), 소인수분해할 수
 * 반환값: f(x) = (x^2 + c) mod n 값
 */
uint64_t f(uint64_t x, uint64_t c, uint64_t n) {
    return (mul_mod(x, x, n) + c) % n;
}

/**
 * 최대공약수(GCD) 계산 함수
 * 
 * 유클리드 알고리즘을 사용하여 두 수의 최대공약수를 계산합니다.
 * Pollard-Rho 알고리즘에서 인수를 찾는 데 사용됩니다.
 * 
 * 매개변수:
 * a, b: 최대공약수를 계산할 두 수
 * 반환값: a와 b의 최대공약수
 */
uint64_t gcd(uint64_t a, uint64_t b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

/**
 * Pollard-Rho 알고리즘을 사용한 인수분해 함수
 * 
 * 주어진 합성수 n의 한 인수를 찾아 반환합니다.
 * 이 알고리즘은 John Pollard가 고안한 확률적 알고리즘으로,
 * 특히 중간 크기의 인수를 효율적으로 찾을 수 있습니다.
 * 
 * 알고리즘 원리:
 * 1. Floyd의 사이클 발견 알고리즘 적용
 * 2. 난수 수열을 생성하고 두 값의 차이의 최대공약수 계산
 * 3. 최대공약수가 1보다 크면 인수를 찾은 것임
 * 
 * 매개변수:
 * n: 인수분해할 수
 * 반환값: n의 한 인수 (인수를 찾지 못하면 n 자체를 반환)
 */
uint64_t pollard_rho(uint64_t n) {
    // 기본 사례 처리
    if (n <= 1) return n;       // 1 이하는 인수분해 불가
    if (!(n & 1)) return 2;     // 짝수는 2로 나눌 수 있음
    if (is_prime(n)) return n;  // 소수는 더 이상 인수분해 불가
    
    // 난수 발생기 초기화
    srand(time(NULL));
    
    uint64_t x, y, c, factor;
    
    // 여러 번 시도 (최대 100회)
    int max_iterations = 100;
    
    while (max_iterations--) {
        // 무작위 시작 값 및 상수 선택
        x = rand() % (n - 1) + 1;  // 1 <= x < n
        y = x;                     // 토끼와 거북이 같은 위치에서 시작
        
        c = rand() % (n - 1) + 1;  // 1 <= c < n (상수항)
        
        factor = 1;
        
        // 사이클이 발견되거나 인수를 찾을 때까지 반복
        while (factor == 1) {
            // '거북이'는 한 번 이동 (느림)
            x = f(x, c, n);
            
            // '토끼'는 두 번 이동 (빠름)
            y = f(y, c, n);
            y = f(y, c, n);
            
            // |x-y|와 n의 최대공약수 계산
            factor = gcd(n, (x > y) ? x - y : y - x);

            // 1과 n이 아닌 인수를 찾았다면 반환
            if (factor != 1 && factor != n)
                return factor;
            
            // 사이클 발견 시 이번 시도 종료
            if (x == y)
                break;
        }
    }
    
    // 인수를 찾지 못한 경우 n 자체를 반환
    return n;
}