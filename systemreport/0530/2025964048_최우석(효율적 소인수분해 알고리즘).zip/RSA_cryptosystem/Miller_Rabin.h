#include <stdint.h>
#ifndef MILLER_RABIN_H
#define MILLER_RABIN_H

uint64_t mul_mod(uint64_t a, uint64_t b, uint64_t mod);
uint64_t mod_pow(uint64_t base, uint64_t exp, uint64_t mod);
int miller_rabin_test(uint64_t n, uint64_t a);
int is_prime(uint64_t n);

#endif // MILLER_RABIN_H