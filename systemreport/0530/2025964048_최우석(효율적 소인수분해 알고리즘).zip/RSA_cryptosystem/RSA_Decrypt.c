#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "Miller_Rabin.h"  // 소수 판별 알고리즘
#include "Pollard_Rho.h"   // 소인수분해 알고리즘
#include "RSA_Utils.h"     // RSA 유틸리티 함수

/**
 * 암호문 파일에서 공개키(n, e)를 읽는 함수
 * 
 * RSA 암호화 시 사용된 공개키 정보는 암호문 파일의 첫 줄에 저장되어 있습니다.
 * 이 함수는 파일에서 모듈러스 n과 지수 e 값을 추출합니다.
 * 
 * 매개변수:
 * infile: 암호문을 포함하는 입력 파일 포인터
 * n: 모듈러스 n을 저장할 포인터
 * e: 지수 e를 저장할 포인터
 * 
 * 반환값: 
 * 성공 시 1, 실패 시 0
 */
int read_public_key_from_ciphertext(FILE* infile, uint64_t* n, uint64_t* e) {
    // 첫 줄에서 n과 e 읽기
    if (fscanf(infile, "%lu %lu", n, e) != 2) {
        printf("암호문 파일에서 n과 e를 읽는데 실패했습니다.\n");
        return 0;
    }
    
    return 1;
}

/**
 * 모듈러스 n을 소인수분해하여 두 소수 p와 q를 찾는 함수
 * 
 * RSA의 보안은 큰 합성수 n = p*q의 소인수분해 난이도에 기반합니다.
 * 이 함수는 Pollard-Rho 알고리즘을 사용하여 n을 소인수분해합니다.
 * 실제 RSA에서는 키가 매우 커서 현실적으로 소인수분해가 어렵지만,
 * 이 구현에서는 교육 목적으로 64비트 이하의 키를 사용합니다.
 * 
 * 매개변수:
 * n: 소인수분해할 모듈러스
 * p: 첫 번째 소수 인수를 저장할 포인터
 * q: 두 번째 소수 인수를 저장할 포인터
 * 
 * 반환값:
 * 성공 시 1, 실패 시 0
 */
int find_factors(uint64_t n, uint64_t* p, uint64_t* q) {
    *p = pollard_rho(n);
    if (*p == 0) {
        printf("소인수분해에 실패했습니다.\n");
        return 0;
    }
    
    *q = n / *p;
    
    // p와 q가 소수인지 확인
    if (!is_prime(*p) || !is_prime(*q)) {
        printf("유효하지 않은 소인수가 발견되었습니다.\n");
        return 0;
    }
    
    return 1;
}

/**
 * 개인키 d를 계산하는 함수
 * 
 * 오일러 토티언트 함수 φ(n) = (p-1)(q-1)을 계산하고,
 * 공개키 e의 모듈러 역원을 구해 개인키 d를 계산합니다.
 * d는 e * d ≡ 1 (mod φ(n))을 만족하는 값입니다.
 * 
 * 매개변수:
 * p, q: 모듈러스 n의 두 소수 인수
 * e: 공개키 지수
 * d: 계산된 개인키를 저장할 포인터
 * 
 * 반환값:
 * 성공 시 1, 실패 시 0
 */
int calculate_private_key(uint64_t p, uint64_t q, uint64_t e, uint64_t* d) {
    // φ(n) = (p-1) * (q-1) 계산
    uint64_t phi_n;
    
    // 오버플로우 방지를 위한 검사
    if (p > UINT64_MAX / (q - 1)) {
        printf("φ(n) 계산 중 오버플로우가 발생했습니다.\n");
        return 0;
    }
    
    phi_n = (p - 1) * (q - 1);
    
    // 모듈러 역원 계산 (확장 유클리드 알고리즘 사용)
    *d = mod_inverse(e, phi_n);
    if (*d == 0) {
        printf("개인키(d) 계산에 실패했습니다. 유효한 모듈러 역원이 존재하지 않습니다.\n");
        return 0;
    }
    
    return 1;
}

/**
 * 암호화된 데이터를 복호화하는 함수
 * 
 * 암호문 파일에서 암호화된 블록들을 읽고, RSA 복호화를 수행합니다.
 * 각 암호문 블록 C에 대해 M = C^d mod n 연산을 수행하여 원본 메시지를 복원합니다.
 * 복호화된 데이터는 출력 파일에 바이트 단위로 기록됩니다.
 * 
 * 매개변수:
 * infile: 암호문이 저장된 입력 파일 포인터
 * outfile: 복호화된 데이터를 기록할 출력 파일 포인터
 * d: 개인키 지수
 * n: 모듈러스
 */
void process_decryption(FILE* infile, FILE* outfile, uint64_t d, uint64_t n) {
    uint64_t C;
    const int BLOCK_SIZE = 6; // 암호화 시 사용한 블록 크기와 동일하게 설정 (48비트)
    
    // 암호문 파일에서 한 블록씩 읽기
    while (fscanf(infile, "%lu", &C) == 1) {
        // RSA 복호화 공식: M = C^d mod n
        uint64_t M = mod_pow(C, d, n);
        
        // 복호화된 정수 값을 바이트 배열로 변환
        uint8_t buffer[BLOCK_SIZE];
        int byte_count = 0;
        
        // 상위 바이트부터 추출 (빅 엔디안 방식)
        for (int i = BLOCK_SIZE - 1; i >= 0; i--) {
            uint8_t byte = (M >> (i * 8)) & 0xFF;
            // 의미 있는 바이트만 추출 (선행 0 제거)
            if (byte != 0 || byte_count > 0) {
                buffer[byte_count++] = byte;
            }
        }
        
        // 적어도 한 바이트는 출력해야 함
        if (byte_count == 0) {
            buffer[0] = 0;
            byte_count = 1;
        }
        
        // 버퍼의 내용을 출력 파일에 쓰기
        fwrite(buffer, 1, byte_count, outfile);
    }
}

/**
 * 메인 함수: RSA 복호화 과정을 조정하고 실행
 * 
 * 명령줄 인수로 암호문 파일 경로를 받아, 다음 단계를 수행합니다:
 * 1. 암호문 파일에서 공개키(n, e) 읽기
 * 2. 모듈러스 n을 소인수분해하여 p와 q 찾기
 * 3. 개인키 d 계산
 * 4. 암호문을 복호화하여 원본 메시지 복원
 * 
 * 매개변수:
 * argc: 명령줄 인수 개수
 * argv: 명령줄 인수 배열 (argv[1]은 암호문 파일 경로)
 * 
 * 반환값:
 * 성공 시 0, 실패 시 1
 */
int main(int argc, char *argv[]) {
    // 명령줄 인수 검사
    if (argc != 2) {
        printf("사용법: %s <암호문파일>\n", argv[0]);
        return 1;
    }
    
    const char* input_file = argv[1];
    uint64_t n, e, p, q, d;
    
    // 암호문 파일 열기
    FILE* infile = fopen(input_file, "r");
    if (infile == NULL) {
        printf("암호문 파일을 열 수 없습니다: %s\n", input_file);
        return 1;
    }
    
    // 공개키(n, e) 읽기
    if (!read_public_key_from_ciphertext(infile, &n, &e)) {
        fclose(infile);
        return 1;
    }
    
    // n을 소인수분해하여 p와 q 찾기
    if (!find_factors(n, &p, &q)) {
        fclose(infile);
        return 1;
    }
    
    // 개인키 d 계산
    if (!calculate_private_key(p, q, e, &d)) {
        fclose(infile);
        return 1;
    }
    
    // 출력은 항상 표준 출력(터미널)으로 설정
    FILE* outfile = stdout;
    
    // 복호화 수행
    process_decryption(infile, outfile, d, n);
    
    // 파일 닫기 및 완료 메시지 출력
    fclose(infile);
    printf("\n복호화가 완료되었습니다.\n");
    
    return 0;
}