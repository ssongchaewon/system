#include <stdint.h>
#ifndef RSA_UTILS_H
#define RSA_UTILS_H

uint64_t mod_inverse(uint64_t a, uint64_t m);

#endif // RSA_UTILS_H