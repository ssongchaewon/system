#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include "Miller_Rabin.h"  // 소수 판별 알고리즘
#include "Pollard_Rho.h"   // gcd 함수 사용

/**
 * 지정된 범위 내에서 64비트 난수를 생성하는 함수
 * 
 * 이 함수는 rand() 함수를 사용하여 64비트 크기의 난수를 생성합니다.
 * 일반적인 rand() 함수는 32비트 값만 생성하므로, 
 * 두 개의 난수를 비트 연산으로 결합하여 64비트 값을 생성합니다.
 * 
 * 매개변수:
 * min: 생성할 난수의 최소값
 * max: 생성할 난수의 최대값
 * 
 * 반환값:
 * min과 max 사이의 균일하게 분포된 난수
 */
static uint64_t generate_random_uint64(uint64_t min, uint64_t max) {
    uint64_t range = max - min + 1;
    uint64_t random_value = ((uint64_t)rand() << 32) | rand();
    return min + (random_value % range);
}

/**
 * 지정된 범위 내에서 큰 소수를 찾는 함수
 * 
 * 이 함수는 지정된 범위 내에서 무작위로 숫자를 선택하고,
 * Miller-Rabin 소수 판별법을 사용하여 소수인지 확인합니다.
 * 소수가 발견될 때까지 이 과정을 반복합니다.
 * 
 * 매개변수:
 * min: 찾을 소수의 최소값
 * max: 찾을 소수의 최대값
 * 
 * 반환값:
 * min과 max 사이의 소수
 */
static uint64_t find_large_prime(uint64_t min, uint64_t max) {
    uint64_t candidate;
    do {
        // 지정된 범위 내에서 난수 생성
        candidate = generate_random_uint64(min, max);
        // 홀수로 만들기 (짝수는 2를 제외하고 모두 합성수)
        if (candidate % 2 == 0)
            candidate++;
    } while (!is_prime(candidate)); // Miller-Rabin 테스트로 소수 판별
    
    return candidate;
}

/**
 * 확장 유클리드 알고리즘을 사용한 모듈러 역원 계산 함수
 * 
 * RSA에서 개인키 d는 공개키 e의 모듈러 역원으로,
 * e * d ≡ 1 (mod φ(n))를 만족하는 값입니다.
 * 이 함수는 확장 유클리드 알고리즘을 사용하여 모듈러 역원을 계산합니다.
 * 
 * 매개변수:
 * e: 역원을 구할 값 (공개키 지수)
 * phi_n: 모듈러 연산의 법(modulus) (오일러 토티언트 함수 값)
 * 
 * 반환값:
 * e의 모듈러 역원, 역원이 존재하지 않으면 0
 */
static uint64_t mod_inverse(uint64_t e, uint64_t phi_n) {
    int64_t r1 = phi_n;
    int64_t r2 = e;
    int64_t t1 = 0;
    int64_t t2 = 1;
    int64_t q, r, t;
    
    // 확장 유클리드 알고리즘 적용
    while (r2 > 0) {
        q = r1 / r2; // 몫 계산
        
        // 나머지 갱신
        r = r1 - q * r2;
        r1 = r2;
        r2 = r;
        
        // 베주 계수 갱신
        t = t1 - q * t2;
        t1 = t2;
        t2 = t;
    }
    
    // gcd(e, phi_n) = 1이 아니면 역원이 존재하지 않음
    if (r1 != 1) return 0;
    
    // 음수인 경우 양수로 변환
    if (t1 < 0) t1 += phi_n;
    
    return t1;
}

/**
 * RSA 키 쌍(공개키, 개인키)을 생성하는 함수
 * 
 * RSA 암호화 알고리즘에 사용될 키 쌍을 생성합니다:
 * 1. 두 개의 큰 소수 p와 q를 생성
 * 2. n = p * q 계산 (모듈러스)
 * 3. φ(n) = (p-1) * (q-1) 계산 (오일러 토티언트 함수)
 * 4. φ(n)과 서로소인 e 선택 (공개키 지수)
 * 5. e의 모듈러 역원 d 계산 (개인키 지수)
 * 
 * 매개변수:
 * n: 계산된 모듈러스 값을 저장할 포인터
 * e: 계산된 공개키 지수를 저장할 포인터
 * d: 계산된 개인키 지수를 저장할 포인터
 * 
 * 반환값:
 * 성공 시 1, 실패 시 0
 */
int generate_rsa_keys(uint64_t *n, uint64_t *e, uint64_t *d) {
    // 난수 생성기 초기화
    srand(time(NULL));
    
    // 큰 소수 p와 q 찾기 (약 30~31비트 크기)
    uint64_t p = find_large_prime(1ULL << 30, 1ULL << 31);
    uint64_t q = find_large_prime(1ULL << 30, 1ULL << 31);
    
    // p와 q가 같으면 다시 생성 (같은 소수를 사용하면 보안 취약점 발생)
    while (p == q) {
        q = find_large_prime(1ULL << 30, 1ULL << 31);
    }
    
    // 모듈러스 n = p * q 계산 (이 값은 공개키의 일부)
    *n = p * q;
    
    // 오일러 토티언트 함수 φ(n) = (p - 1) * (q - 1) 계산
    uint64_t phi_n = (p - 1) * (q - 1);
    
    // 공개키 지수 e 선택 (φ(n)과 서로소인 값)
    do {
        // 65537(2^16 + 1) 이상의 랜덤 홀수 생성
        // 65537은 일반적으로 사용되는 공개키 지수 값으로, 충분히 큰 소수임
        *e = (rand() % (phi_n / 2)) * 2 + 65537;
        
        // φ(n)보다 작은지 확인
        if (*e >= phi_n) {
            *e = 65537; // 기본값으로 설정
        }
        
    } while (gcd(*e, phi_n) != 1); // e와 φ(n)이 서로소인지 확인
    
    // 랜덤 생성에 실패했을 경우 대체 방법 시도
    if (*e >= phi_n) {
        // 일반적으로 사용되는 값 65537 시도
        *e = 65537;
        if (gcd(*e, phi_n) != 1) {
            // 다른 후보 e 값 순차적으로 시도 (홀수만)
            for (*e = 65539; *e < phi_n; *e += 2) {
                if (gcd(*e, phi_n) == 1) break;
            }
            
            // 적절한 e를 찾지 못한 경우
            if (*e >= phi_n) {
                return 0; // 키 생성 실패
            }
        }
    }
    
    // 개인키 지수 d 계산 (e의 모듈러 역원)
    *d = mod_inverse(*e, phi_n);
    
    // 유효한 d를 계산하지 못한 경우
    if (*d == 0) {
        return 0; // 키 생성 실패
    }
    
    return 1; // 키 생성 성공
}
