#include <stdint.h>
#ifndef RSA_KEYGEN_H
#define RSA_KEYGEN_H
  
int generate_rsa_keys(uint64_t *n, uint64_t *e, uint64_t *d);

#endif // RSA_KEYGEN_H