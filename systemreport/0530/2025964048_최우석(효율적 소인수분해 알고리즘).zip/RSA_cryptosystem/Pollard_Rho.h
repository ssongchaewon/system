#include <stdint.h>
#include "Miller_Rabin.h" // Needs definitions from Miller_Rabin
#ifndef POLLARD_RHO_H
#define POLLARD_RHO_H

uint64_t f(uint64_t x, uint64_t c, uint64_t n); // May not need to be public
uint64_t gcd(uint64_t a, uint64_t b);
uint64_t pollard_rho(uint64_t n);

#endif // POLLARD_RHO_H