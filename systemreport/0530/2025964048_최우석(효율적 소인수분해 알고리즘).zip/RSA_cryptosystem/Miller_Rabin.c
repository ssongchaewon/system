#include <stdio.h>
#include <stdint.h> // 64비트 정수형을 위한 헤더

/**
 * 모듈러 곱셈 연산 함수 (a * b) % mod
 * 
 * 일반적인 곱셈 후 나머지 연산은 큰 수에서 오버플로우가 발생할 수 있어
 * 러시안 페전트 곱셈 알고리즘을 사용하여 오버플로우 없이 계산합니다.
 * 
 * 매개변수:
 * a: 첫 번째 피연산자
 * b: 두 번째 피연산자
 * mod: 모듈러 연산의 법(modulus)
 * 반환값: (a * b) % mod 값
 */
uint64_t mul_mod(uint64_t a, uint64_t b, uint64_t mod) {
    // 작은 수의 경우 직접 계산 (최적화)
    const uint64_t Threshold = UINT64_C(1) << 32; // 2^32 임계값
    
    if (a < Threshold && b < Threshold)
        return (a * b) % mod;
    
    uint64_t result = 0;
    a %= mod; // 먼저 피연산자들을 모듈러 연산
    b %= mod;
    
    // 러시안 페전트 알고리즘 구현
    // b를 이진수로 표현했을 때 각 비트에 대해 처리
    while (b > 0) {
        // b의 최하위 비트가 1이면 현재 a값을 결과에 더함
        if (b & 1) {
            // 덧셈 시 오버플로우 방지를 위한 처리
            if (result >= mod - a)
                result -= (mod - a); // mod - a는 (-a) mod m과 동일
            else
                result += a;
        }
        
        // a를 2배로 만들고 모듈러 연산 적용 (다음 비트 위치 준비)
        if (a >= mod - a)
            a -= (mod - a);
        else
            a += a;
        
        b >>= 1; // b를 오른쪽으로 1비트 시프트 (다음 비트 확인)
    }
    
    return result;
}

/**
 * 모듈러 거듭제곱 연산 함수 (base^exp) % mod
 * 
 * 거듭제곱을 효율적으로 계산하기 위한 이진 지수 알고리즘을 사용합니다.
 * 계산 과정에서 오버플로우를 방지하기 위해 mul_mod 함수를 사용합니다.
 * 
 * 매개변수:
 * base: 밑(거듭제곱 할 수)
 * exp: 지수
 * mod: 모듈러 연산의 법(modulus)
 * 반환값: (base^exp) % mod 값
 */
uint64_t mod_pow(uint64_t base, uint64_t exp, uint64_t mod) {
    uint64_t result = 1;
    base = base % mod; // 먼저 base를 모듈러 연산
    
    // 이진 지수 알고리즘(Square-and-Multiply) 사용
    while (exp > 0) {
        // exp의 최하위 비트가 1이면 현재 base를 결과에 곱함
        if (exp & 1)
            result = mul_mod(result, base, mod);
        
        // base를 제곱하고 모듈러 연산 적용
        base = mul_mod(base, base, mod);
        exp >>= 1; // exp를 오른쪽으로 1비트 시프트
    }
    
    return result;
}

/**
 * Miller-Rabin 소수 판별 테스트 (단일 기저에 대한 검사)
 * 
 * n-1 = d * 2^r 형태로 분해 후, a^d mod n 값을 계산하여
 * 페르마의 소정리와 밀러-라빈 판별법에 따라 소수 여부를 판별합니다.
 * 
 * 매개변수:
 * n: 소수 판별할 수
 * a: 테스트에 사용할 기저(base)
 * 반환값: 소수일 가능성이 있으면 1, 확실히 합성수면 0
 */
int miller_rabin_test(uint64_t n, uint64_t a) {
    // n-1 = d * 2^r 형태로 분해 (d는 홀수)
    uint64_t d = n - 1;
    int r = 0;
    
    // d에서 2의 인수를 모두 제거하여 홀수 d 찾기
    while (!(d & 1)) {
        d >>= 1; // d를 2로 나누기
        r++;     // 2의 지수 증가
    }
    
    // a^d mod n 계산
    uint64_t x = mod_pow(a, d, n);
    
    // 페르마의 소정리에 따른 첫 번째 확인
    // a^d ≡ 1 (mod n) 또는 a^d ≡ -1 (mod n)
    if (x == 1 || x == n - 1)
        return 1; // 소수일 가능성 있음
    
    // a^(d*2^j) mod n 값을 r-1번 확인
    for (int i = 0; i < r - 1; i++) {
        x = mul_mod(x, x, n); // x = x^2 mod n
        
        // 어느 단계에서든 -1 mod n이 나오면 소수일 가능성 있음
        if (x == n - 1)
            return 1;
    }
    
    // 모든 조건을 만족하지 못하면 합성수
    return 0;
}

/**
 * 주어진 수가 소수인지 판별하는 함수
 * 
 * 밀러-라빈 소수 판별법을 여러 기저(base)에 대해 수행하여
 * 소수 여부를 높은 확률로 판별합니다. 
 * 2^64 범위 내의 수에 대해 완전한 판별이 가능합니다.
 * 
 * 매개변수:
 * n: 소수 판별할 수
 * 반환값: 소수이면 1, 아니면 0
 */
int is_prime(uint64_t n) {
    // 기본 케이스 처리
    if (n <= 1) return 0;      // 1 이하는 소수가 아님
    if (!(n & 1)) return (n == 2); // 짝수는 2만 소수
    
    // 밀러-라빈 테스트에 사용할 기저(base) 목록
    // 이 기저들로 2^64 이하의 모든 수에 대한 소수 판별이 가능
    uint64_t bases[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37};
    
    // 테스트할 수가 기저 중 하나인 경우 즉시 소수로 판별
    for (int i = 0; i < 12; i++) {
        if (n == bases[i])
            return 1;
    }
    
    // 각 기저에 대해 밀러-라빈 테스트 수행
    // 하나라도 테스트를 통과하지 못하면 합성수
    for (int i = 0; i < 12; i++) {
        if (bases[i] < n && !miller_rabin_test(n, bases[i]))
            return 0; // 합성수로 확정
    }
    
    // 모든 테스트를 통과하면 소수로 판단
    return 1;
}