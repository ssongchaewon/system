#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "Pollard_Rho.h"  // 소인수분해 알고리즘

#define MAX_FACTORS 100   // 최대 인수 개수 정의

/**
 * 소인수와 지수 쌍을 저장하는 구조체
 * 
 * 소인수분해 결과를 p^a × q^b × ... 형태로 나타내기 위해
 * 각 소인수(prime)와 그 지수(exponent)를 함께 저장합니다.
 */
typedef struct {
    uint64_t prime;    // 소인수
    int exponent;      // 지수(등장 횟수)
} PrimeFactor;

/**
 * 숫자를 소인수분해하여 모든 인수를 배열에 저장하는 함수
 * 
 * Pollard-Rho 알고리즘을 사용하여 주어진 숫자를 소인수분해하고
 * 모든 소인수를 배열에 저장합니다. 이 함수는 재귀적으로 동작하여
 * 발견된 각 인수를 더 작은 소인수로 분해합니다.
 * 
 * 매개변수:
 * n: 소인수분해할 숫자
 * factors: 발견된 소인수를 저장할 배열
 * num_factors: 현재까지 발견된 소인수의 개수를 저장하는 포인터
 */
void factorize_to_array(uint64_t n, uint64_t factors[], int *num_factors) {
    // 1이면 소인수가 없음
    if (n <= 1) {
        return;
    }
    
    // 처음부터 소수인 경우 바로 배열에 추가
    if (is_prime(n)) {
        factors[*num_factors] = n;
        (*num_factors)++;
        return;
    }
    
    // Pollard-Rho 알고리즘으로 인수 찾기
    uint64_t factor = pollard_rho(n);
    
    // 인수를 찾지 못한 경우(알고리즘 실패)
    // 또는 이미 소수인 경우
    if (factor == n) {
        factors[*num_factors] = n;
        (*num_factors)++;
        return;
    }
    
    // 재귀적으로 인수분해: 찾은 인수와 남은 몫을 각각 분해
    factorize_to_array(factor, factors, num_factors);
    factorize_to_array(n / factor, factors, num_factors);
}

/**
 * 소인수 배열을 정렬하고 지수 형태로 변환하는 함수
 * 
 * 발견된 모든 소인수를 정렬하고, 같은 소인수는 지수 형태로 통합합니다.
 * 예: [2,2,3,5,5,5] -> [(2,2), (3,1), (5,3)]와 같이 변환
 * 
 * 매개변수:
 * factors: 발견된 모든 소인수가 저장된 배열
 * num_factors: 소인수의 총 개수
 * prime_factors: 변환된 (소인수, 지수) 쌍을 저장할 구조체 배열
 * 
 * 반환값:
 * 변환된 (소인수, 지수) 쌍의 총 개수
 */
int convert_to_prime_factors(uint64_t factors[], int num_factors, PrimeFactor prime_factors[]) {
    if (num_factors == 0) {
        return 0;
    }
    
    // 버블 정렬로 인수 오름차순 정렬
    for (int i = 0; i < num_factors - 1; i++) {
        for (int j = 0; j < num_factors - i - 1; j++) {
            if (factors[j] > factors[j + 1]) {
                uint64_t temp = factors[j];
                factors[j] = factors[j + 1];
                factors[j + 1] = temp;
            }
        }
    }
    
    // 정렬된 인수 배열을 (소인수, 지수) 형태로 변환
    int count = 0;  // 서로 다른 소인수의 개수
    
    // 첫 번째 소인수 초기화
    prime_factors[0].prime = factors[0];
    prime_factors[0].exponent = 1;
    
    // 나머지 소인수 처리
    for (int i = 1; i < num_factors; i++) {
        // 이전 소인수와 같으면 지수만 증가
        if (factors[i] == prime_factors[count].prime) {
            prime_factors[count].exponent++;
        } 
        // 새로운 소인수면 새 항목 추가
        else {
            count++;
            prime_factors[count].prime = factors[i];
            prime_factors[count].exponent = 1;
        }
    }
    
    // 서로 다른 소인수의 총 개수 반환
    return count + 1;
}

/**
 * 메인 함수: 사용자 입력을 받아 소인수분해 실행
 * 
 * 사용자로부터 소인수분해할 정수를 입력받고,
 * 소인수분해 후 결과를 지수 표기법으로 출력합니다.
 * 
 * 소인수분해 과정:
 * 1. 사용자로부터 정수 입력 받기
 * 2. 숫자를 소인수분해하여 모든 인수 찾기
 * 3. 찾은 인수를 정렬하고 지수 형태로 변환
 * 4. 결과를 a^n × b^m × ... 형태로 출력
 * 
 * 반환값:
 * 성공 시 0, 실패 시 1
 */
int main() {
    uint64_t n;
    printf("소인수분해할 정수를 입력하세요: ");
    
    // 입력 유효성 검사: scanf 반환값 확인
    if (scanf("%lu", &n) != 1) {
        printf("입력 오류가 발생했습니다.\n");
        return 1;
    }
    
    printf("%lu의 소인수분해 결과: ", n);
    
    // 특수 케이스 처리: 1 이하의 수
    if (n <= 1) {
        printf("%lu는 소인수가 없습니다.\n", n);
        return 0;
    }
    
    // 소인수를 저장할 배열 및 변수 초기화
    uint64_t factors[MAX_FACTORS];
    int num_factors = 0;
    
    // 소인수분해 실행
    factorize_to_array(n, factors, &num_factors);
    
    // 소인수를 지수 형태로 변환
    PrimeFactor prime_factors[MAX_FACTORS];
    int num_prime_factors = convert_to_prime_factors(factors, num_factors, prime_factors);
    
    // 소인수분해 결과 출력 (p^a × q^b × ... 형태)
    for (int i = 0; i < num_prime_factors; i++) {
        // 지수가 1보다 크면 지수 표기법 사용
        if (prime_factors[i].exponent > 1) {
            printf("%lu^%d", prime_factors[i].prime, prime_factors[i].exponent);
        } 
        // 지수가 1이면 소인수만 표시
        else {
            printf("%lu", prime_factors[i].prime);
        }
        
        // 마지막 소인수가 아니면 곱셈 기호 출력
        if (i < num_prime_factors - 1) {
            printf(" × ");
        }
    }
    printf("\n");
    
    return 0;
}
 